Matrix 360 Lakhotia AI Revision v1.3 — LOCAL PILOT

Prerequisite: Existing v1.2 creative revision system working on Windows.

1. Stop uvicorn (Ctrl+C). Back up your data folder.
2. Copy install_ai_revision_v13.py, start_lakhotia_with_ai.py and entire upgrade_files folder into your lakhotia_agentic_pilot folder.
3. In Command Prompt (inside project folder): python install_ai_revision_v13.py
4. Start: python start_lakhotia_with_ai.py
   Enter your OpenAI API key in the hidden prompt. Do NOT share it in chat or save it in a screenshot/source code.
5. Open http://127.0.0.1:8001/revisions/<your-draft-id>/2
   Click "Open AI Revision Agent". Submit feedback once. Allow up to ~50 seconds.
6. Compare latest Version N with previous Version N-1. New AI revisions are unapproved.

The OpenAI API is PAID independently of ChatGPT subscriptions and usage consumes credits.
This system sends your creative content and revision feedback to OpenAI. Do not include private lead/customer data.
Local demo only: self-declared reviewer identity, no live publishing or ad spend.
The AI can select one of the three v1.2 deterministic layouts; it is NOT image generation or unrestricted graphical redesign.
Model defaults to gpt-4.1-mini; change MATRIX_MODEL only if necessary and supported by your API account.
If the AI produces unsupported claims, the system rejects it and saves no new version.
No API key is persisted to disk by the launcher. API errors are surfaced; no silent offline fallback.
