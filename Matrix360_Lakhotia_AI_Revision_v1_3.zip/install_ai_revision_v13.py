"""Install AI Revision v1.3 onto v1.2. No database files are touched."""
from pathlib import Path
import shutil, ast, datetime
base=Path(__file__).resolve().parent
if not all((base/name).is_file() for name in ('app.py','engine.py','revision_agent.py','visual_layouts_v12.py','review_addon.py')):
    raise SystemExit('ERROR: v1.2 files missing. Install v1.2 before AI v1.3.')
source=base/'upgrade_files'/'ai_revision_v13.py'
if not source.is_file():raise SystemExit('ERROR: Missing upgrade_files/ai_revision_v13.py')
ast.parse(source.read_text(encoding='utf8'))
app_file=base/'app.py'
old=app_file.read_text(encoding='utf8')
addon='\nfrom ai_revision_v13 import router as ai_revision_router\napp.include_router(ai_revision_router)\n'
if 'app.include_router(ai_revision_router)' not in old:
    ast.parse(old+addon)
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    shutil.copy2(app_file,base/f'app_before_ai_v13_{stamp}.py')
    app_file.write_text(old+addon,encoding='utf8')
shutil.copy2(source,base/'ai_revision_v13.py')
# Add a discoverable link to the old revision UI (minimal, replace-only-once).
rfile=base/'revision_agent.py'; rs=rfile.read_text(encoding='utf8')
needle='<h1>Option {opt} — revision workspace</h1>'
if needle in rs and 'Open AI Revision Agent' not in rs:
    shutil.copy2(rfile,base/f'revision_agent_before_ai_v13_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}.py')
    rs=rs.replace(needle,needle+'<p><a href="/ai-revisions/{escape(draft_id)}/{opt}">Open AI Revision Agent →</a></p>',1)
    ast.parse(rs)
    rfile.write_text(rs,encoding='utf8')
print('SUCCESS: AI Revision v1.3 installed. No existing drafts or PNGs changed.')
print('Launch using: python start_lakhotia_with_ai.py')
print('Open /revisions/<draft-id>/2 then click Open AI Revision Agent.')
