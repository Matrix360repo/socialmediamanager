"""Start the existing Matrix360 local pilot with a session-only OpenAI API key.
No credential is written to disk. Run this file from the folder containing app.py.
"""
import getpass
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
if not (root / 'app.py').is_file() or not (root / 'engine.py').is_file():
    print('ERROR: Place this launcher alongside app.py and engine.py.')
    sys.exit(1)
if not (root / 'data' / 'brand_profile.json').exists():
    print('ERROR: data/brand_profile.json not found.')
    sys.exit(1)
print('Matrix 360 — Lakhotia Local AI Drafting')
print('Your key is entered locally and will not be saved in any file.')
key = getpass.getpass('Paste OpenAI API key (input hidden), then press Enter: ').strip()
if not key:
    print('ERROR: No key entered.'); sys.exit(1)
env = os.environ.copy()
env['OPENAI_API_KEY'] = key
env.setdefault('MATRIX_MODEL', 'gpt-4.1-mini')
env.pop('MATRIX360_CLOUD_MODE', None)
print('Starting localhost app. Leave this window open. Press Ctrl+C to stop.')
print('Open: http://127.0.0.1:8001/')
try:
    result = subprocess.run([sys.executable, '-m', 'uvicorn', 'app:app', '--host', '127.0.0.1', '--port', '8001'], cwd=str(root), env=env, check=False)
    sys.exit(result.returncode)
except KeyboardInterrupt:
    print('\nStopped.')
except FileNotFoundError as exc:
    print('Start failed:', exc)
    sys.exit(1)
